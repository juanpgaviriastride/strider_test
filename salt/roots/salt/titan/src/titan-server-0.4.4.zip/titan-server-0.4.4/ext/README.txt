Place all extension jars (and their dependencies) in this directory and they will be loaded when Titan Server is started.
